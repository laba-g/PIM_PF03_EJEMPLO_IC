import 'package:comarcasgui/themes/tema_comarcas.dart';
import 'package:flutter/material.dart';
import 'package:comarcasgui/screens/form_screen.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Material App',
      debugShowCheckedModeBanner: false,
      theme: temaComarcas,
      home: const Scaffold(
        body: MyRegisterForm(),
      ),
    );
  }
}
//