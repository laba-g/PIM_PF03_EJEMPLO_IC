//import 'package:comarcasgui/screens/comarcas_screen.dart';
import 'package:comarcasgui/screens/provincias_screen.dart';
import 'package:flutter/material.dart';

class MyRegisterForm extends StatefulWidget {
  const MyRegisterForm({super.key});

  @override
  MyRegisterFormState createState() {
    return MyRegisterFormState();
  }
}
class MyRegisterFormState extends State<MyRegisterForm> {
  
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _controlador1 = TextEditingController();
  final TextEditingController _controlador2 = TextEditingController();

 @override
  void dispose() {
    _controlador1.dispose();
    _controlador2.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                blurRadius: 8,
                offset: const Offset(0, 4),
                color: Colors.black.withOpacity(0.15),
              ),
            ],
          ),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Text(
                  "Iniciar Sesión",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                createRegisterNameFormField(),
                const SizedBox(height: 16),
                createRegisterPasswordFormField(),
                const SizedBox(height: 20),
                createSubmitButton(context),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  @override
  void initState() {
    super.initState();
    _controlador1.text = "";
  }

 
  TextFormField createRegisterNameFormField() {
    return TextFormField(
      controller: _controlador1,
     
      validator: (value) {
        if (value?.isEmpty ?? true) {
          return 'No puede estar vacío';
        }
       
        final regexCorreu = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');

        if (!regexCorreu.hasMatch(value ?? "")) {
          return 'La dirección de correo no es válida';
        }
        return null;
      },

      decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          icon: const Icon(Icons.email),
          labelText: "Dirección de correo",
      ),
    );
  }
  TextFormField createRegisterPasswordFormField() {
    return TextFormField(
      controller: _controlador2,
      obscureText: true,
      validator: (value) {
        if (value?.isEmpty ?? true) {
          return 'No puede estar vacío';
        }
        return null;
      },

      decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          icon: const Icon(Icons.lock),
          labelText: "Contraseña",
      ),
    );
  }
  Widget createSubmitButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: ElevatedButton(
        onPressed: () {
          if (_formKey.currentState?.validate() ?? false ) {
            if (_formKey.currentState?.validate() ?? false ) {
              Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ProvinciasScreen()),
                );
          }
          } else{
            muestraAlertDialog(context);
          }
        },
        child: const Text('Iniciar sesión'),
      ),
    );
  }
  Future<String?> muestraAlertDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text("Error"),
            content: const Text("El usuario o la contraseña son incorrectas"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context, "volver");
                },
                child: const Text("volver"),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context, "Rellenar usuario");
                },
                child: const Text("Rellenar usuario"),
              ),
            ],
          );
        });
  }
}
/*
class MyRegisterForm extends StatefulWidget {
  const MyRegisterForm({super.key});

  @override
  MyRegisterFormState createState() {
    return MyRegisterFormState();
  }
}
class MyRegisterFormState extends State<MyRegisterForm> {
  
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _controlador1 = TextEditingController();
  final TextEditingController _controlador2 = TextEditingController();

 @override
  void dispose() {
    _controlador1.dispose();
    _controlador2.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16.0),
        children: <Widget>[

          createRegisterNameFormField(),
          const SizedBox(height: 16),
          createRegisterPasswordFormField(),
          const SizedBox(height: 16),
          createSubmitButton(context),
        ],
      ),

    );
  }  
  
  @override
  void initState() {
    super.initState();
    _controlador1.text = "";
  }

 
  TextFormField createRegisterNameFormField() {
    return TextFormField(
      controller: _controlador1,
     
      validator: (value) {
        if (value?.isEmpty ?? true) {
          return 'No puede estar vacío';
        }
       
        final regexCorreu = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');

        if (!regexCorreu.hasMatch(value ?? "")) {
          return 'La dirección de correo no es válida';
        }
        return null;
      },

      decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          icon: const Icon(Icons.email),
          labelText: "Dirección de correo",
      ),
    );
  }
  TextFormField createRegisterPasswordFormField() {
    
    return TextFormField(
      
      controller: _controlador2,
      validator: (value) {
        if (value?.isEmpty ?? true) {
          return 'No puede estar vacío';
        }
        return null;
      },

      decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          icon: const Icon(Icons.lock),
          labelText: "Contraseña",
      ),
    );
  }
  Widget createSubmitButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: ElevatedButton(
        onPressed: () {
          if (_formKey.currentState?.validate() ?? false ) {
            if (_formKey.currentState?.validate() ?? false ) {
            // aqui te lleva a otra pagina
          }
          } else{
            
          }
        },
        child: const Text('Iniciar sesión'),
      ),
    );
  }
}
 */
 