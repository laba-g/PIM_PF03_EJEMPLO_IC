import 'package:comarcasgui/models/comarca.dart';
import 'package:comarcasgui/repository/repository_comarcas.dart';
import 'package:comarcasgui/screens/widgets/my_circular_progress_indicator.dart';
//import 'package:comarcasgui/repository/repository_ejemplo_Antiguo.dart';
import 'package:flutter/material.dart';




class InfoComarcaGeneral extends StatelessWidget {
  final String comarcaName;

  const InfoComarcaGeneral({
    super.key,
    required this.comarcaName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: FutureBuilder<Comarca?>(
        future: RepositoryComarcas.obtenerInfoComarca(comarcaName),
        builder: (context, snapshot) {

         
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: MyCircularProgressIndicator());
          }

          
          if (snapshot.hasError) {
            return const Center(child: Text("Error al cargar la comarca"));
          }

          
          if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text("No hay información disponible"));
          }

          
          final comarca = snapshot.data!;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.network(
                  comarca.img ?? '',
                  fit: BoxFit.cover,
                  width: double.infinity,
                ),
                const SizedBox(height: 16),

                
                Text(
                  comarca.comarca,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),

                Text(
                  "Capital: ${comarca.capital ?? ''}",
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 16),

                Text(
                  comarca.desc ?? '',
                  style: Theme.of(context).textTheme.bodyLarge,
                  textAlign: TextAlign.justify,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/*
class InfoComarcaGeneral extends StatelessWidget {
  final String comarcaName;
  const InfoComarcaGeneral({
    super.key,
    required this.comarcaName,
  });

  @override
  Widget build(BuildContext context) {
    // Agafem la comarca del repositori
    Comarca? comarca = RepositoryComarcas.obtenerInfoComarca(comarcaName);

    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
              comarca!.img ?? '',
              fit: BoxFit.cover,
              width: double.infinity,
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    comarca.comarca,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    // extend o expand ns
                    "Capital: ${comarca.capital ?? ''}",
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    comarca.desc ?? '',
                    style: Theme.of(context).textTheme.bodyLarge,
                    textAlign: TextAlign.justify,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
*/