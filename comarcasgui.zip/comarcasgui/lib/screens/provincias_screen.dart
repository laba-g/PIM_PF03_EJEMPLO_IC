import 'package:comarcasgui/models/provincia.dart';
import 'package:comarcasgui/repository/repository_comarcas.dart';
import 'package:comarcasgui/screens/widgets/my_circular_progress_indicator.dart';
import 'package:flutter/material.dart';
import 'package:comarcasgui/screens/comarcas_screen.dart';

/* Pantalla ProvinciasScreen: muestra tres CircleAvatar con las distintas provincias */
class ProvinciasScreen extends StatelessWidget {
  const ProvinciasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: FutureBuilder<List<Provincia>>(
          future: RepositoryComarcas.obtenerProvincias(),
          builder: (context, snapshot) {
            
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const MyCircularProgressIndicator();
            }

            if (snapshot.hasError) {
              return const Text("Error cargando provincias");
            }

            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Text("No hay provincias disponibles");
            }

            final provincias = snapshot.data!;

            return SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: _creaListaProvincias(provincias),
              ),
            );
          },
        ),
      ),
    );
  }
}

List<Widget> _creaListaProvincias(List<Provincia> provincias) {
  // Actualiza con gesture detector y push

  List<Widget> lista = [];

  for (Provincia provincia in provincias) {
    lista.add(ProvinciaRoundButton(
        nombre: provincia.nombre, imagen: provincia.imagen ?? ""));
    lista.add(const SizedBox(height: 20));
  }
  return lista;
}

class ProvinciaRoundButton extends StatelessWidget {
  const ProvinciaRoundButton(
      {required this.imagen, required this.nombre, super.key});

  final String imagen;
  final String nombre;

  @override
  Widget build(BuildContext context) {
    
    return ElevatedButton(
      style: ElevatedButton.styleFrom(// forma circular
        padding: EdgeInsets.zero, // sin espacio extra
        elevation: 5,
      ),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ComarcasScreen(provincia: nombre),
          ),
        );
      },
      child: CircleAvatar(
        radius: 110,
        backgroundImage: NetworkImage(imagen),
        child: Text(nombre,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.displayMedium),
      ),
    );
  }
}
/*
return CircleAvatar(
      radius: 110,
      backgroundImage: NetworkImage(imagen),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black38, // ligera capa oscura para resaltar texto
          borderRadius: BorderRadius.circular(110),
        ),
        alignment: Alignment.center,
        child: Text(
          nombre,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.displayMedium
        ),
      ),
    );
  }
}
 title:  Text("Comarques d'Alacant",
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.displayMedium),
 */
