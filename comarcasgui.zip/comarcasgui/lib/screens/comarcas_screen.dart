import 'package:comarcasgui/repository/repository_comarcas.dart';
import 'package:comarcasgui/screens/infocomarca_completa.dart';
import 'package:comarcasgui/screens/widgets/my_circular_progress_indicator.dart';
import 'package:flutter/material.dart';

class ComarcasScreen extends StatelessWidget {
  final String provincia;

  const ComarcasScreen({super.key, required this.provincia});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Comarcas de $provincia',
          textAlign: TextAlign.center,
          style: Theme.of(context)
              .textTheme
              .displayMedium
              ?.copyWith(color: Colors.black, shadows: []),
        ),
      ),

      body: FutureBuilder<List<dynamic>>(
        future: RepositoryComarcas.obtenerComarcas(provincia),
        builder: (context, snapshot) {

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: MyCircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(child: Text("Error cargando comarcas"));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No hay comarcas disponibles"));
          }

          final comarques = snapshot.data!;

          return _creaListaComarcas(comarques);
        },
      ),
    );
  }

  Widget _creaListaComarcas(List<dynamic> comarques) {
    return ListView.builder(
      itemCount: comarques.length,
      itemBuilder: (context, index) {
        final comarca = comarques[index];
        final nombre = comarca['nombre'];
        final imagen = comarca['img'];

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ComarcaCard(
            comarca: nombre,
            img: imagen,
          ),
        );
      },
    );
  }
}
class ComarcaCard extends StatelessWidget {
  const ComarcaCard({
    super.key,
    required this.img,
    required this.comarca,
  });

  final String img;
  final String comarca;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.zero,
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => InfocomarcaCompleta(comarcaName: comarca),
          ),
        );
      },
      child: SizedBox(
        height: 175,
        width: double.infinity,
        child: Stack(
          children: [
            Image.network(
              img,
              fit: BoxFit.cover,
              height: 175,
              width: double.infinity,
            ),

            Positioned(
              left: 12,
              bottom: 12,
              child: Text(
                comarca,
                style: Theme.of(context)
                    .textTheme
                    .displaySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/*

class ComarcasScreen extends StatelessWidget {
  final String provincia;
  const ComarcasScreen({super.key, required this.provincia});

  @override
  Future<Widget> build(BuildContext context) async {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Comarcas de $provincia',
          textAlign: TextAlign.center,
          style: Theme.of(context)
              .textTheme
              .displayMedium
              ?.copyWith(color: Colors.black, shadows: []),
        ),
      ),
      body: Center(
          child: _creaListaComarcas(
              await RepositoryComarcas.obtenerComarcas(provincia))), ////
    );
  }

  _creaListaComarcas(List<dynamic> comarques) {
    return ListView.builder(
      itemCount: comarques.length,
      itemBuilder: (context, index) {
        final comarca = comarques[index];
        final nombre = comarca['nombre'];
        final imagen = comarca['img'];

         return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), // separación
          child: ComarcaCard(
            comarca: nombre,
            img: imagen,
          ),
        );
      },
    );
  }
}
class ComarcaCard extends StatelessWidget {
  const ComarcaCard({
    super.key,
    required this.img,
    required this.comarca,
  });

  final String img;
  final String comarca;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.zero,
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => InfocomarcaCompleta(comarcaName: comarca),
          ),
        );
      },
      child: SizedBox(
        height: 175,
        width: double.infinity,
        child: Stack(
          children: [
            Image.network(
              img,
              fit: BoxFit.cover,
              height: 175,
              width: double.infinity,
            ),

            Positioned(
              left: 12,
              bottom: 12,
              child: Text(
                comarca,
                style: Theme.of(context)
                    .textTheme
                    .displaySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

 */