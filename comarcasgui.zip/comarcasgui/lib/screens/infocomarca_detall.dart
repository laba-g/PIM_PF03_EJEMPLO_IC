import 'package:comarcasgui/models/comarca.dart';
import 'package:comarcasgui/repository/repository_comarcas.dart';
import 'package:comarcasgui/screens/widgets/my_circular_progress_indicator.dart';
import 'package:comarcasgui/screens/widgets/my_weather_info.dart';
import 'package:flutter/material.dart';

class InfoComarcaDetall extends StatelessWidget {
  final String comarcaName;
  const InfoComarcaDetall({
    super.key,  required this.comarcaName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<Comarca?>(
        future: RepositoryComarcas.obtenerInfoComarca(comarcaName),
        builder: (context, snapshot) {
          
          // ⏳ Mientras carga
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: MyCircularProgressIndicator());
          }

          // ❌ Si hay error
          if (snapshot.hasError) {
            return const Center(child: Text("Error al cargar la información"));
          }

          // ⚠️ Si no hay datos
          if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text("No hay información disponible"));
          }

          // ✔️ Datos cargados
          final comarca = snapshot.data!;

          return SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 10),
                const MyWeatherInfo(),
                const SizedBox(height: 20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Població: "),
                    Text("${comarca.poblacion ?? 'N/A'}"),
                  ],
                ),

                const SizedBox(height: 10),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Latitud: "),
                    Text("${comarca.latitud ?? 'N/A'}"),
                  ],
                ),

                const SizedBox(height: 10),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Longitud: "),
                    Text("${comarca.longitud ?? 'N/A'}"),
                  ],
                ),

                const SizedBox(height: 20),
              ],
            ),
          );
        },
      ),
    );
  }
}



/*
  @override
  Future<Widget> FutureBuilder(BuildContext context) async {
    Comarca? comarca = await RepositoryComarcas.obtenerInfoComarca(comarcaName);
    
    return Scaffold(
      body: SingleChildScrollView(
        //padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 10),
            const MyWeatherInfo(),
            const SizedBox(height: 20),

           Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Població: "),
                Text("${comarca!.poblacion}"),
              ],
            ),

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Latitud: "),
                Text("${comarca.latitud}"),
              ],
            ),

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Longitud: "),
                Text("${comarca.longitud}"),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

*/