import 'package:comarcasgui/screens/infocomarca_detall.dart';
import 'package:comarcasgui/screens/infocomarca_general.dart';
import 'package:flutter/material.dart';

class InfocomarcaCompleta extends StatefulWidget {
  final String comarcaName;
  const InfocomarcaCompleta({super.key, required this.comarcaName});

  @override
  State<InfocomarcaCompleta> createState() => InfocomarcaCompletaState();
}

class InfocomarcaCompletaState extends State<InfocomarcaCompleta> {
  int indexActual = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      InfoComarcaGeneral(comarcaName: widget.comarcaName),
      InfoComarcaDetall(comarcaName: widget.comarcaName),
    ];

    final titles = [
      Text(
        'Información General',
        textAlign: TextAlign.center,
        style: Theme.of(context)
            .textTheme
            .displayMedium
            ?.copyWith(color: Colors.black, 
            shadows: []), 
      ),
      Text('Població i oratge',
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme .displayMedium?.
        copyWith(color: Colors.black, shadows: []),),
    ];

    return Scaffold(
      appBar: AppBar(
        title: titles[indexActual],
        centerTitle: true,
      ),
      body: pages[indexActual],
      bottomNavigationBar: NavigationBar(
        selectedIndex: indexActual,
        onDestinationSelected: (int index) {
          setState(() {
            indexActual = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.info_outline),
            selectedIcon: Icon(Icons.info),
            label: 'Información general',
          ),
          NavigationDestination(
            icon: Icon(Icons.wb_sunny_outlined),
            selectedIcon: Icon(Icons.sunny),
            label: 'Información detallada',
          ),
        ],
      ),
    );
  }
}
